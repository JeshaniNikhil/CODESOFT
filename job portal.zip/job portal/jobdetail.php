<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
<header>
        <center><h1>Avaliable Jobs</h1></center><hr>
        <?php
        error_reporting(0);
    $con=mysqli_connect("localhost","root","","job"); 
    $catg1=$_REQUEST['cata'];
$location1=$_REQUEST['loca'];
$search=$_REQUEST['search'];
    $sel="select * from `post` where `catg`='$catg1' OR `location`='$location1'";
    $sql=mysqli_query($con,$sel);
    //$num=mysqli_num_rows($sql);
    ?>
        <center><h1>Avaliable Jobs</h1></center><hr>
    <header>
        <?php
        if($num=mysqli_num_rows($sql)>0)
        {
        while($row=mysqli_fetch_assoc($sql))
        {
        ?>
        <hr>
        <center><h1>Company Name:<?php echo $row['cmpnm'];?></h1></center>
        <center><h1>Categorie:<?php echo $row['catg'];?></h1></center>
        <center><h1>Location:<?php echo $row['location']; ?></h1></center>
        <center><h1>Email:<?php echo $row['email'];?></h1></center>
        <center><h1>Contact no:<?php  echo $row['cn']; ?></h1></center>
        <center><h1>Address:<?php echo $row['address'] ?></h1></center>
        <?php 
    }
}
else
{
    echo "<h1> job was not available as soon as possible we will notify you"."<h1>";
}

    ?>
    </header>
</body>
</html>