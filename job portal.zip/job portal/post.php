<?php
$con = mysqli_connect("localhost","root","","job");
$cmpnm=$_REQUEST['cmpnm'];
$catg=$_REQUEST['catg'];
$location=$_REQUEST['location'];
$email=$_REQUEST['email'];
$cn=$_REQUEST['cn'];
$address=$_REQUEST['address'];
$insert="INSERT INTO `post`(`cmpnm`, `catg`, `location`, `email`, `cn`, `address`) VALUES ('$cmpnm','$catg','$location','$email','$cn','$address')";
$query= mysqli_query($con,$insert);
?>