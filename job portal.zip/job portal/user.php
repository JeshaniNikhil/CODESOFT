<?php
$con=mysqli_connect("localhost","root","","job"); 
$fnm= $_REQUEST['fnm'];
$gender= $_REQUEST['gender'];
$nationality=$_REQUEST['nationality'];
$lang=$_REQUEST['lang'];
$hobbies=$_REQUEST['hobbies'];
$des=$_REQUEST['des'];
$email=$_REQUEST['email'];
$cnm=$_REQUEST['cnm'];
$insert = "insert into `emp` (`fnm`,`gender`,`nationality`,`lang`,`hobbies`,`des`,`email`,`cnm`) values('$fnm','$gender','$nationality','$lang','$hobbies','$des','$email','$cnm')";
echo "<script>console.log($insert)";
$query = mysqli_query($con,$insert);
?>