<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Job Listing Page</title>
</head>
<style>
*
{
    padding:0;
margin:0;
display:border-box;
}
body 
{

}
</style>
<body>
    <?php
    $con=mysqli_connect("localhost","root","","job"); 
    $sel="select * from `post`";
    $sql=mysqli_query($con,$sel);
    // $num=mysqli_num_rows($sql);
    ?>
    <header>
        <?php
        while($row=mysqli_fetch_assoc($sql))
        {
        ?>
        <hr>
        <center><h1>Avaliable Jobs</h1></center><hr>
        <center><h1>Company Name:<?php echo $row['cmpnm'];?></h1></center>
        <center><h1>Categorie:<?php echo $row['catg'];?></h1></center>
        <center><h1>Location:<?php echo $row['location']; ?></h1></center>
        <center><h1>Email:<?php echo $row['email'];?></h1></center>
        <center><h1>Contact no:<?php  echo $row['cn']; ?></h1></center>
        <center><h1>Address:<?php echo $row['address'] ?></h1></center>
        <?php 
    }
    ?>
    </header>
</body>
</html>