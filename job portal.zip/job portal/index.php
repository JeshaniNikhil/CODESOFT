<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-KK94CHFLLe+nY2dmCWGMq91rCGa5gtU4mk92HdvYe+M/SXH301p5ILy+dN9+nJOZ" crossorigin="anonymous">
<script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/popper.js@1.14.7/dist/umd/popper.min.js" integrity="sha384-UO2eT0CpHqdSJQ6hJty5KVphtPhzWj9WO1clHTMGa3JDZwrnQq4sF86dIHNDz0W1" crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@4.3.1/dist/js/bootstrap.min.js" integrity="sha384-JjSmVgyd0p3pXB1rRibZUAYoIIy6OrQ6VrjIEaFf/nJGzIxFDsf4x0xIM+B07jRM" crossorigin="anonymous"></script>
<style>
/*    *{
        margin:0;
        padding:0;
        box-sizing:border-box;
    }
    .navbar li,a
    {
        margin:0;
        padding:0;
        list-style:none;
    }    
*/
img
{
     background-image: url('slider2.jpg');
     height: 500px;
     width: 100%;
     background-repeat:none;
     
}
.con
{
  position: relative;
  text-align: center;
  color: white;
}
.nav
{
    position: absolute;
  top: 8px;
  right: 16px;
}
select
{
  height:40px;
  width:150px;
}
</style>
</head>
<body>
    <div class="con">
<ul class="nav justify-content-center">
  <li class="nav-item">
    <a class="nav-link active" aria-current="page" href="#" style=" border-bottom: none; font-weight:bolder">Home</a>
  </li>
  <li class="nav-item">
    <a class="nav-link" href="#" style=" border-bottom: none; font-weight:bolder">Browse job</a>
  </li>
    <li class="nav-item dropdown">
        <a style=" border-bottom: none; font-weight:bolder" class="nav-link dropdown-toggle" href="#" id="navbarDropdownMenuLink" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
          Page
        </a>
        <div class="dropdown-menu" aria-labelledby="navbarDropdownMenuLink">
          <a class="dropdown-item" href="joblisting.php">joblisting</a>
          <a class="dropdown-item" href="emp.php">Employe Dashboard</a>
        </div>
      </li>
      <li class="nav-item dropdown">
        <a style=" border-bottom: none; font-weight:bolder" 
        class="nav-link dropdown-toggle" href="#" id="navbarDropdownMenuLink" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
          Blog
        </a>
        <div class="dropdown-menu" aria-labelledby="navbarDropdownMenuLink">
          <a class="dropdown-item" href="https://www.wikipedia.org/">Wikipedia</a>
        </div>
      </li>
  <li class="nav-item">
    <a style=" border-bottom: none; font-weight:bolder" class="nav-link" href="contact.html">Contact</a>
  </li>  <button type="button" class="btn btn-primary" data-toggle="modal" data-target="#modal">Register</button>
  &nbsp <button type="button" class="btn btn-primary" data-toggle="modal" data-target="#modal1">Post Job</button>
  <div class=" mt-3 modal fade" id="modal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                <span style="color:black">Registration Page</span>
                  <button type="button" class="close btn btn-danger"  data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true" class="" style="padding: 0; border: none; background: none;">x</span>
                    </button>
                </div>
                <div class="modal-body">
                    <form method="get" action="user.php">
                    <input class="form-control"  name="fnm" type="text" placeholder="full name"><br>
                    <span style="color:black">Gender:</span>
                    <select  name="gender" class="form-control">  
                      <option>male</option> 
                      <option>female</option>
                    </select><br>
                    <input name="nationality"  class="form-control" type="text" placeholder="nationality"><br>
                    <input name="lang"  class="form-control" type="text" name="" id="" placeholder="known languages"><br>
                    <input name="hobbies"  class="form-control" type="text" name="" placeholder="hobbies" id=""><br>
                    <span></span>
                   <input name="des"  class="form-control" type="textarea" placeholder="discription"><br>
                    <input name="email"  class="form-control" type="email" name="" placeholder="email here" id=""><br>
                    <input name="cnm"  class="form-control" type="number" name="" placeholder="contact number" id=""><br>
                    <input name="submit" name="btn"  type="submit" class="form-control btn btn-primary btn-sm" style="width:100%;" value="login">
                    </form>
                </div>                  
            </div> 
        </div>
    </div> 
    <div class=" mt-3 modal fade" id="modal1" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                <span style="color:black">Post Job</span>
                  <button type="button" class="close btn btn-danger"  data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true" class="" style="padding: 0; border: none; background: none;">x</span>
                    </button>
                </div>
                <div class="modal-body">
                    <form action="post.php">
                    <input class="form-control" name="cmpnm" type="text" placeholder="Company Name:"><br>
                    <span style="color:black">Category of Post:</span>
                    <select class="form-control" name="catg">
      <option value="Category" >Category</option>
      <option value="I.t">I.t</option>
      <option value="Q.a">Q.a</option>
                    </select>
                    <br>
      <span style="color:black">Location:</span>
      <select class="form-control" name="location">
      <option value="select location">Select location</option>
      <option value="Rajkot">Rajkot</option>
      <option value="Ahmedabad">Ahmedabad</option>
      <option value="vadodara">Vadodara</option>
      <option value="jamnagar">Jamnagar</option>
   </select><br>
                    <input class="form-control" name="email" type="text" placeholder="Email"><br>
                    <input class="form-control" name="cn" type="number" name="" placeholder="contact number" id=""><br>
                    <input class="form-control" name="address" type="text" name="" id="" placeholder="Address:"><br>
                    <input type="submit" class="form-control btn btn-primary btn-sm" style="width:100%;" value="login">
                    </form>
                </div>
            </div>
        </div>
    </div> 
</li>
</ul>
<img src="slider2.jpg" alt="">
    </div>
    <br>
    <br>
    <br>
    <form action="jobdetail.php">
  <center>    <div class="dropdown">
    <input type="text" style="height:40px; width:150px;" name="search" placeholder="Search Keyword">
  <select name="loca">
      <option>Select location</option>
      <option name="Rajkot">Rajkot</option>
      <option name="Ahmedabad">Ahmedabad</option>
      <option name="Vadodara">Vadodara</option>
      <option name="Jamnagar">Jamnagar</option>
   </select>
    <select name="cata">
      <option value="Category" >Category</option>
      <option value="I.t" >I.t</option>
      <option value="Q.a" >Q.a</option>
      <option value="Careers" >Careers adviser</option>
    </select>
    <input name="submit" type="submit" class="btn btn-primary sm" value="Submit" style="width:200px; margin-bottom:6px; height:43px">
</center>
</div>
    </form>
</body>
</html>